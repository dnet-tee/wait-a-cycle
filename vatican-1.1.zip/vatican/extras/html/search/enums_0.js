var searchData=
[
  ['verifystate',['VerifyState',['../vatican_8h.html#a03a01e1c4da4a22efc1b7ccdef8991b2',1,'vatican.h']]]
];
