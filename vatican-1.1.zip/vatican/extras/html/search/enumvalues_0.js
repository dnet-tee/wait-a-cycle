var searchData=
[
  ['invalid',['INVALID',['../vatican_8h.html#a03a01e1c4da4a22efc1b7ccdef8991b2aef2863a469df3ea6871d640e3669a2f2',1,'vatican.h']]]
];
