var searchData=
[
  ['salsa20_5fctx_5ft',['salsa20_ctx_t',['../structsalsa20__ctx__t.html',1,'']]],
  ['securechannel',['SecureChannel',['../class_secure_channel.html',1,'']]]
];
