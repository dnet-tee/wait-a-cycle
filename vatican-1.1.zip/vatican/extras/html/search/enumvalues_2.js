var searchData=
[
  ['spoofed_5fsender',['SPOOFED_SENDER',['../vatican_8h.html#a03a01e1c4da4a22efc1b7ccdef8991b2a843379bf578ea47e92580ad503b184b4',1,'vatican.h']]]
];
