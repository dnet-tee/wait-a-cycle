var searchData=
[
  ['addvaticanchannel',['AddVatiCANChannel',['../class_vati_c_a_n_senders.html#ab46edc4e881638b2893fb64d7f42be2b',1,'VatiCANSenders::AddVatiCANChannel()'],['../class_vati_c_a_n.html#a2d34ebc0404dcc5a78dba8cf2cde7938',1,'VatiCAN::AddVatiCANChannel()']]],
  ['available',['Available',['../class_vati_c_a_n.html#a079ee8ecd0bbc5d44d8c026c26ea53eb',1,'VatiCAN']]]
];
