var searchData=
[
  ['vatican',['VatiCAN',['../class_vati_c_a_n.html',1,'VatiCAN'],['../class_vati_c_a_n.html#a8955f68c67b4e009696bd5f8054d6b62',1,'VatiCAN::VatiCAN()']]],
  ['vatican_2ecpp',['vatican.cpp',['../vatican_8cpp.html',1,'']]],
  ['vatican_2eh',['vatican.h',['../vatican_8h.html',1,'']]],
  ['vaticansenders',['VatiCANSenders',['../class_vati_c_a_n_senders.html',1,'VatiCANSenders'],['../class_vati_c_a_n_senders.html#a77bf20c64cb5d374f6195f2ecf6fc5ba',1,'VatiCANSenders::VatiCANSenders()']]],
  ['verifystate',['VerifyState',['../vatican_8h.html#a03a01e1c4da4a22efc1b7ccdef8991b2',1,'vatican.h']]]
];
