var searchData=
[
  ['vatican',['VatiCAN',['../class_vati_c_a_n.html#a8955f68c67b4e009696bd5f8054d6b62',1,'VatiCAN']]],
  ['vaticansenders',['VatiCANSenders',['../class_vati_c_a_n_senders.html#a77bf20c64cb5d374f6195f2ecf6fc5ba',1,'VatiCANSenders']]]
];
