var searchData=
[
  ['vatican_2ecpp',['vatican.cpp',['../vatican_8cpp.html',1,'']]],
  ['vatican_2eh',['vatican.h',['../vatican_8h.html',1,'']]]
];
