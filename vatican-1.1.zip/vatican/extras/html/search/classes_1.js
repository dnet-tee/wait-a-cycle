var searchData=
[
  ['vatican',['VatiCAN',['../class_vati_c_a_n.html',1,'']]],
  ['vaticansenders',['VatiCANSenders',['../class_vati_c_a_n_senders.html',1,'']]]
];
