var searchData=
[
  ['mac_5fok',['MAC_OK',['../vatican_8h.html#a03a01e1c4da4a22efc1b7ccdef8991b2a2394a63e938b14a86e7577bb86d3bdf2',1,'vatican.h']]],
  ['mac_5fwrong',['MAC_WRONG',['../vatican_8h.html#a03a01e1c4da4a22efc1b7ccdef8991b2a1a3dd4aebf077a3f5e0b3824cab8bcbe',1,'vatican.h']]],
  ['msg_5fraw',['MSG_RAW',['../vatican_8h.html#a03a01e1c4da4a22efc1b7ccdef8991b2aeecc16ad76205d550ff11b4b15924a3b',1,'vatican.h']]]
];
