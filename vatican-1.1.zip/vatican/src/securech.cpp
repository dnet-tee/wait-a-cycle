#include "Arduino.h"
#include "securech.h"

SecureChannel::SecureChannel() :
LegacyID(0),
VatiCANID(0),
RemoteCounter(0ul) // must be updated by the Global Nonce counter
{

}

SecureChannel::SecureChannel(CANSENDER legacyCANID, CANSENDER vatiCANID) :
LegacyID(legacyCANID),
VatiCANID(vatiCANID),
RemoteCounter(0ul) // must be updated by the Global Nonce counter
{

}

bool SecureChannel::IsMyID(CANSENDER id)
{
  return IsLegacyCANID(id) || IsVatiCANID(id);
}

bool SecureChannel::IsLegacyCANID(CANSENDER id)
{
  return (id == LegacyID);
}

bool SecureChannel::IsVatiCANID(CANSENDER id)
{
  return (id == VatiCANID);
}

VatiCANSenders::VatiCANSenders() :
_channelsUsed(0)
{

}



bool VatiCANSenders::AddVatiCANChannel(CANSENDER legacyCANID, CANSENDER vatiCANID)
{
  if (_channelsUsed >= MAX_SECSENDERS)
  {
    // too many requests
    return false;
  }

  _channels[_channelsUsed] = SecureChannel(legacyCANID, vatiCANID);
  _channelsUsed++;

  return true;
}

SecureChannel* VatiCANSenders::GetChannel(CANSENDER sender)
{
  uint8_t i;
  SecureChannel* item = NULL;

  // TODO: Rather use a hash map instead -> O(1)
  for(i = 0; i < _channelsUsed; i++)
  {
    item = &_channels[i];
    if (item->IsMyID(sender))
    {
      return item;
    }
  }

  // not found
  return NULL;
}

void VatiCANSenders::ResetCounters(uint64_t newValue)
{
  uint8_t i;

  for(i = 0; i < _channelsUsed; i++)
  {
    _channels[i].RemoteCounter = newValue;
  }
}
