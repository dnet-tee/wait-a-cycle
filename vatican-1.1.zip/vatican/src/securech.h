#ifndef _SECURE_MSG_H
#define _SECURE_MSG_H

#define MAX_SECSENDERS 5

typedef uint16_t CANSENDER;


/**
 * Internal class that represents a CAN ID pair of legacy/VatiCAN
 */
class SecureChannel
{
public:
    CANSENDER LegacyID;
    CANSENDER VatiCANID;
    uint64_t RemoteCounter;
    uint8_t MAC[8];
    uint8_t Payload[8];
    uint8_t Length;


    /**
     * Default constructor such that the array can be initialized.
     * The class is not really usful in that state. The 2nd Constructor
     * should be used intead.
     */
    SecureChannel();

    /**
     * Creates a new object that saves the relation between legacy and
     * VatiCAN IDs.
     * @param legacyCANID The legacy CAN ID that is still used to transmit the payload
     * @param vatiCANID   CAN ID that will be used to transmit the VatiCAN MAC
     */
    SecureChannel(CANSENDER legacyCANID, CANSENDER vatiCANID);

    /**
     * Returns whether the given ID is either a legacy CAN or VatiCAN ID
     * @param  id ID to check
     * @return    @a true if @a id is either the legacy ID or VatiCAN ID.
     */
    bool IsMyID(CANSENDER id);

    /**
     * Returns whether the specified ID is the VatiCAN ID of this channel
     * @param  id CAN ID to check
     * @return    <code>true</code> if ID is this channel's VatiCAN ID
     */
    bool IsVatiCANID(CANSENDER id);

    /**
     * Returns whether the specified ID is the legacy ID of this channel.
     * @param  id CAN ID to check
     * @return    <code>true</code> if ID is this channel's legacy ID
     */
    bool IsLegacyCANID(CANSENDER id);


};

/**
 * Internal list of all secure CAN ID
 */
class VatiCANSenders
{
public:

  /**
   * Adds a new VatiCAN channel to the internal list of all VatiCAN channels
   * @param  legacyCANID The legacy payload CAN ID
   * @param  vatiCANID   The additional VatiCAN CAN ID
   * @return             <code>true</code> if new channel added, <code>false</code>
   * if list already full.
   */
  bool AddVatiCANChannel(CANSENDER legacyCANID, CANSENDER vatiCANID);

  /**
  * Constructor
  */
  VatiCANSenders();

  /**
   * Returns whether the specified <code>sender</code> is part of a
   * legacy/vatiCAN pair (i.e., is either of those IDs)
   * @param  sender The CAN ID to check
   * @return        SecureChannel pointer or NULL if unknown
   */
  SecureChannel* GetChannel(CANSENDER sender);

  /**
   * Initializes the counters of all secure channels to the
   * given value
   * @param newValue Counter to use from now on
   */
  void ResetCounters(uint64_t newValue);



private:
  uint8_t _channelsUsed;
  SecureChannel _channels[MAX_SECSENDERS];

};

#endif
