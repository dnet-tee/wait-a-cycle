/**
  * @file vatican.h
  * @author Stefan Nürnberger <nuernberger@cispa.saarland>, Center for IT-Security, Privacy & Accountability
  * @brief VatiCAN - Vetted, Authenticated CAN Bus
  *
  * Library for authentication of CAN messages
  *
  * Created by Center for IT Security, Privacy & Accountability (CISPA)
  * www.cispa.saarland
  *
  * Foreig Source Code Used:
  * KECCACK: https://github.com/gvanas/KeccakCodePackage
  * SALSA20: https://github.com/cantora/avr-crypto-lib/blob/master/salsa20
  * MCP_CAN: https://github.com/Seeed-Studio/CAN_BUS_Shield
  *
  * LICENSE:
  * This software is free to use for non-commercial purposes under the condition
  * that credits are given (see above).
  * If you plan to use this software commercially or conduct research with the
  * prospect of commercial use, please contact
  * nuernberger@cispa.saarland (CC: office@cispa.saarland)
  * to get further information on licensing requirements and a quote.
*/
#ifndef VATICAN_h
#define VATICAN_h

#include "Arduino.h"
#include <mcp_can.h>

#define MAC_LENGTH_BITS	64
#define MAC_LENGTH_BYTES	(MAC_LENGTH_BITS / 8)

#define MAC_BLOCK_BITS		128
#define MAC_BLOCK_BYTES	(MAC_BLOCK_BITS / 8)

#define MULTIPLE_BLOCK_BYTES(x) (((x + MAC_BLOCK_BYTES - 1) / MAC_BLOCK_BYTES) * MAC_BLOCK_BYTES)

#include "securech.h"
#include "salsa20.h"
#include "KeccakSpongeWidth200.h"

#define VATICAN_FAVOUR_PERFORMANCE 8
#define VATICAN_BALANCED 64
#define VATICAN_SECURE   128
#define VATICAN_STRONG   192

/**
 * Return State for the <code>Available()</code> function
 */
enum VerifyState : uint8_t
{
  NOTHING = 0,        /// Nothing to do, no new messages

  MAC_OK = 5,         /// New VatICAN message received and verified
  MAC_WRONG = 6,      /// New VatiCAN message received but wrong or corrupted
  SPOOFED_SENDER = 7, /// Somebody else on the bus using the same CAN ID

  MSG_RAW = 0xf0,     /// A legacy, un-authenticated message was received

  INVALID = 0xff      /// Invalid internal state
};


class VatiCAN
{
  public:

    uint32_t TotalMessagesSent = 0u;
    uint32_t TotalMessagesRecvd = 0u;
    uint32_t NonceIntervall = 0u;
    bool ForwardNoncePacket = false;

  	/**
  	 * Creates a new VatiCAN instance
  	 * @param password      The password for the keyed-hash authentication
  	 * @param spongeCap     The capacity of the underlying sponge function (security/performance tradeoff)
  	 * @param can           Unerlying CAN bus interface
  	 * @param globalNonceID The CAN ID that the Nonce (send/receive) will use
  	 */
    VatiCAN(const char* password, uint16_t spongeCap, MCP_CAN& can, CANSENDER globalNonceID);

    /**
     * Starts to send a new global Nonce every <code>everyMS</code> milliseconds.
     * @param everyMS Interval between Nonce updates
     */
    void StartNonceServer(uint32_t everyMS);

    /**
     * Stops sending Nonces to others
     */
    void StopNonceServer();

    /**
     * Computes a keyed-hash message authentication code (MAC)
     * @param ID The sender/receiver CAN ID that is used for computing the MAC
     * @param msg The message for which to compute the code
     * @param msglength The length of that message (typically 1 to 8 bytes for CAN)
     * @param mac Buffer to save the MAC to (64 bits)
     */
    void MessageAuthentication(CANSENDER ID, uint64_t counter, const uint8_t* msg, int16_t msglength, uint8_t* mac);

    /**
     * Sends a message over the CAN bus.
     * If the sender <code>id</code> is in the list of secure IDs,
     * an MAC is automatically appended and sent from the
     * authentication ID.
     * @param id The sender's ID
     * @param payload The bytes to send (0 to 8)
     * @param len The length of the supplied payload
     */
    void Send(CANSENDER id, uint8_t* payload, uint8_t len);

    /**
     * Registers a CAN ID for use with VatiCAN authenticated
     * messages.
     * Its authentication channel (usually ID + 1) must be specified
     * as well.
     * @param legacyID The ID to add to the list
     * @param vatiCANID The ID to be used for MACs
     * @return <code>true</code> if sucessfully added to the list,
     * <code>false</code> if list was full.
     */
    bool AddVatiCANChannel(CANSENDER legacyID, CANSENDER vatiCANID);

    /**
     * Needs to be called regularly.
     * This function does the heav-duty lifting (MAC calculation) of
     * arrived messages. It is done asynchronously and not while a
     * a new message arrives in order to lift the burden off the ISR.
     * @param id Return value that holds the sender's CAN ID (legacy ID, never VatiCAN ID)
     * @param buffer Return value that points to the payload buffer
     * @param length Return value that holds the payload's length
     * @return <code>NOTHING</code> if no new messages, otherwise one of
     * <code>MAC_OK</code>, <code>MAC_WRONG</code> for VatiCAN messages or
     * <code>MSG_RAW</code> for legacy un-authenticated messages
     */
    VerifyState Available(CANSENDER& id, uint8_t** buffer, uint8_t& lenght);

    /**
     * Returns the current counter for a remote ID
     * @param  id CAN ID to check for
     * @return    That CAN ID's current counter or <code>0ul</code> if invalid.
     */
    uint64_t GetRemoteCounter(CANSENDER id);

    /**
     * Returns the currently valid global nonce
     * @return The currently valid global nonce
     */
    uint64_t GetGlobalNonce();

    /**
     * Uses the AVR hardware (floating inputs) to generate noise
     * and use it to generate randomness
     * @param buffer Buffer to be filled, byte by byte
     * @param length Length of that buffer
     */
    void FillRealRandom(uint8_t* buffer, uint8_t length);


  private:

    MCP_CAN& _can;
    CANSENDER _globalNonceID;

    uint8_t* _key;
    uint64_t _freshness[2];
    uint64_t* _globalNonce;
    uint32_t _lastNonceUpdate = 0ul; // time stamp

    VatiCANSenders _vatiSenders;
    uint8_t _tempBuffer[8];

    salsa20_ctx_t _csprng;
    KeccakWidth200_SpongeInstance _sponge;
    uint16_t _spongeCapacity;

    /**
     * Internal function that is regularly called and calculates a
     * new Nonce, which is then broadcasted.
     */
    void BroadcastNonce();

    /**
     * Generates a cryptographically secure (not predictable, almost not repeating) random number
     * based on the SALSA20 stream cipher
     * @return 64-bit random number
     */
    uint64_t GetNewRandomNonce();


};

#endif /* VatiCAN */
