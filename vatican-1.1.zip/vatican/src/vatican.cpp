/**
  * @file vatican.cpp
  * @author Stefan Nürnberger <nuernberger@cispa.saarland>, Center for IT-Security, Privacy & Accountability
  * @brief VatiCAN - Vetted, Authenticated CAN Bus
  *
  * Library for authentication of CAN messages
  *
  * Created by Center for IT Security, Privacy & Accountability (CISPA)
  * www.cispa.saarland
  *
  * Foreig Source Code Used:
  * KECCACK: https://github.com/gvanas/KeccakCodePackage
  * SALSA20: https://github.com/cantora/avr-crypto-lib/blob/master/salsa20
  * MCP_CAN: https://github.com/Seeed-Studio/CAN_BUS_Shield
  *
  * LICENSE:
  * This software is free to use for non-commercial purposes under the condition
  * that credits are given (see above).
  * If you plan to use this software commercially or conduct research with the
  * prospect of commercial use, please contact
  * nuernberger@cispa.saarland (CC: office@cispa.saarland)
  * to get further information on licensing requirements and a quote.
*/

#include <Arduino.h>
#include <string.h>
#include <mcp_can.h>
#include <stdint.h>
#include <string.h>
#include "vatican.h"
#include "securech.h"
#include "salsa20.h"

// use 64-bit passwords for now
#define KEYLEN 8

void LowLevelInterrupt();
volatile bool NewCANMessage = false;

VatiCAN::VatiCAN(const char* password, uint16_t spongeCap, MCP_CAN& can, CANSENDER globalNonceID) :
_can(can),
_globalNonceID(globalNonceID),
_globalNonce(&_freshness[0]),
_spongeCapacity(spongeCap)
{

  // keep a local copy, scope of 'password' might be lost
  // we limit/pad the key to KEYLEN
  uint8_t pwLen = strlen(password);
  if (pwLen > KEYLEN) pwLen = KEYLEN;
  _key = (uint8_t*)malloc(KEYLEN);
  memcpy(_key, password, pwLen);
  memset(_key + pwLen, 0x55, KEYLEN - pwLen); // padding, if necessary

  attachInterrupt(0, &LowLevelInterrupt, FALLING); // register ISR

  *_globalNonce = 0ul;
  _lastNonceUpdate = millis();

  // initialise the Cyrptographically Secure Pseudo Random Number Generator (CSPRNG)
  uint8_t seed[16];
  FillRealRandom(seed, sizeof(seed));
  salsa20_init(seed, 128, NULL, &_csprng);
}

void LowLevelInterrupt()
{
  NewCANMessage = true;
}

void VatiCAN::FillRealRandom(uint8_t* buffer, uint8_t length)
{
  for(int b = 0; b < length; b++)
  {
    buffer[b] = analogRead(A1) & 0x03;
    buffer[b] <<= 2;
    buffer[b] |= analogRead(A2) & 0x03;
    buffer[b] <<= 2;
    buffer[b] |= analogRead(A3) & 0x03;
    buffer[b] <<= 2;
    buffer[b] |= analogRead(A4) & 0x03;
  }
}

void VatiCAN::Send(CANSENDER id, uint8_t* payload, uint8_t len)
{
  SecureChannel* ch = _vatiSenders.GetChannel(id);
  _can.sendMsgBuf(id, 0, len, payload);
  TotalMessagesSent++;
  if (ch)
  {
    // is a VatiCAN channel -> attach MAC
    uint8_t mac[8];
    MessageAuthentication(id, ch->RemoteCounter, payload, len, mac);
    _can.sendMsgBuf(ch->VatiCANID, 0, 8, mac);
    ch->RemoteCounter++;
    TotalMessagesSent++;
  }
}

bool VatiCAN::AddVatiCANChannel(CANSENDER legacyID, CANSENDER vatiCANID)
{
  return _vatiSenders.AddVatiCANChannel(legacyID, vatiCANID);
}

void VatiCAN::StartNonceServer(uint32_t everyMS)
{
  NonceIntervall = everyMS;
}

void VatiCAN::StopNonceServer()
{
  NonceIntervall = 0u;
}

uint64_t VatiCAN::GetNewRandomNonce()
{
  return salsa20_gen64(&_csprng);
}

void VatiCAN::BroadcastNonce()
{
  *_globalNonce = GetNewRandomNonce();
  _vatiSenders.ResetCounters(*_globalNonce);
  _can.sendMsgBuf(_globalNonceID, 0, sizeof(uint64_t), reinterpret_cast<uint8_t*>(_globalNonce));
  TotalMessagesSent++;
}

VerifyState VatiCAN::Available(CANSENDER& id, uint8_t** buffer, uint8_t& length)
{

  VerifyState res = NOTHING;

  uint32_t currTime = millis();
  if (NonceIntervall > 0 && (currTime - _lastNonceUpdate > NonceIntervall)) {
    BroadcastNonce();
    _lastNonceUpdate = currTime;
  }

  if (NewCANMessage || (CAN_MSGAVAIL == _can.checkReceive()))
  {
    NewCANMessage = false;
    TotalMessagesRecvd++;
    unsigned long canID;
    _can.readMsgBufID(&canID, &length, _tempBuffer);
    id = canID;

    if (id == _globalNonceID)
    {
      uint64_t* noncePtr = reinterpret_cast<uint64_t*>(_tempBuffer);
      // NOTE: Ideally, the _globalNonce would not be updated immediately but
      // only when there are no legacy packages awaiting a VatiCAN package.
      *_globalNonce = *noncePtr;
      _vatiSenders.ResetCounters(*_globalNonce);
      if (ForwardNoncePacket) {
        *buffer = _tempBuffer;
        res = MSG_RAW;
      }
    } else {
      // check if this is payload, authentication or something else
      SecureChannel* ch = _vatiSenders.GetChannel(id);

      if (ch)
      {
        // it is from a secure channel, so either the legacy ID
        // or the MAC (VatiCAN) ID
        if (ch->IsVatiCANID(id)) {
          // VatiCAN ID, legacy must have been received before
          if (memcmp(ch->MAC, _tempBuffer, 8) == 0) {
            res = MAC_OK;
            ch->RemoteCounter++;
          } else {
            res = MAC_WRONG;
          }
          *buffer = ch->Payload;
          length = ch->Length;
          id = ch->LegacyID;
        } else {
          // legacy ID, vatiCAN will follow
          ch->Length = length;
          memcpy(ch->Payload, _tempBuffer, length);
          MessageAuthentication(id, ch->RemoteCounter, _tempBuffer, length, ch->MAC);

        }
      } else {
        // we don't know what it is. Just forward it
        *buffer = _tempBuffer;
        res = MSG_RAW;
      }
    }
  }
  return res;
}

uint64_t VatiCAN::GetRemoteCounter(CANSENDER id)
{
  SecureChannel* ch = _vatiSenders.GetChannel(id);
  if (ch)
  {
    return ch->RemoteCounter;
  } else {
    return 0ul;
  }
}

uint64_t VatiCAN::GetGlobalNonce()
{
  return *_globalNonce;
}


void VatiCAN::MessageAuthentication(CANSENDER ID, uint64_t counter, const uint8_t* msg, int16_t msglength, uint8_t* mac)
{
  /* We don't need the traditional MAC construction as
   * keccak is not prone to length-extension.
   * Quote from author's website:
   * Unlike SHA-1 and SHA-2, Keccak does not have the length-extension weakness,
   * hence does not need the MAC nested construction. Instead, MAC computation
   * can be performed by simply prepending the message with the key.
   */

  KeccakWidth200_SpongeInitialize(&_sponge, 200 - _spongeCapacity, _spongeCapacity);

  KeccakWidth200_SpongeAbsorb(&_sponge, _key, KEYLEN);


  // The space the global Nonce and the ID-specific counter
  // is exactly MAC_BLOCK_BYTES

  // _freshness[0] = *_globalNonce;
  _freshness[1] = (counter << 11) | (ID & 0x7FF); // concatenate the 53-bit local counter with the 11-bit ID

  KeccakWidth200_SpongeAbsorb(&_sponge, reinterpret_cast<uint8_t*>(_freshness), sizeof(_freshness));
  KeccakWidth200_SpongeAbsorb(&_sponge, msg, msglength);
  KeccakWidth200_SpongeAbsorbLastFewBits(&_sponge, 0x01);
  KeccakWidth200_SpongeSqueeze(&_sponge, mac, 8); // get 64 bit MAC
}
