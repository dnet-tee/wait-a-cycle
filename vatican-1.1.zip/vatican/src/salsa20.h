/* salsa20.h */
/*
    This file is part of the AVR-Crypto-Lib.
    Copyright (C) 2011 Daniel Otte (daniel.otte@rub.de)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

		2017-12-12 Stefan Nürnberger
		Modified to work with C++
*/

#ifndef SALSA20_H_
#define SALSA20_H_


typedef struct  {
	union{
		uint8_t   v8[64];
		uint64_t v64[ 8];
	} a;
	uint8_t buffer[64];
	uint8_t buffer_idx;
} salsa20_ctx_t;

#ifdef __cplusplus
extern "C" {
#endif

void salsa20_hash(uint32_t *a);

void salsa20_init(void *key, uint16_t keylength_b, void *iv, salsa20_ctx_t *ctx);
uint64_t salsa20_gen64(salsa20_ctx_t *ctx);

#ifdef __cplusplus
}
#endif

#endif /* SALSA20_H_ */
